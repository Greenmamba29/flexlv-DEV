
import React from 'react';
import { Button } from "@/components/ui/button";
import { Instagram, MessageSquare, Copy, Gift, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ReferralSection = () => {
  const { toast } = useToast();
  const [showLoyaltyInfo, setShowLoyaltyInfo] = React.useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText('https://flexurluv.com/refer?id=YOURCODE');
    toast({
      title: "Link Copied!",
      description: "Your referral link has been copied to clipboard",
    });
  };

  const loyaltyTiers = [
    { name: "Bronze", credits: 1, features: ["1 story credit/month", "Basic templates"] },
    { name: "Silver", credits: 3, features: ["3 story credits/month", "Premium templates"] },
    { name: "Gold", credits: 5, features: ["5 story credits/month", "All templates", "1 free domain/year"] },
    { name: "Luv Legend", credits: 10, features: ["10 story credits/month", "All templates", "3 free domains/year", "Priority support"] }
  ];

  return (
    <section className="py-16 bg-white" id="referral">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between max-w-5xl mx-auto bg-gradient-to-br from-lavender/10 to-teal/10 rounded-xl p-6 border border-gray-100">
          <div className="flex-1 mb-6 md:mb-0">
            <h3 className="text-2xl font-bold mb-2">Share the magic — and get rewards.</h3>
            <p className="text-gray-600 max-w-md">
              Refer friends and earn discounts on future story gifts. Join our community of storytellers.
            </p>
          </div>
          
          <div className="flex flex-col items-center text-center">
            <div className="mb-4">
              <div className="inline-block relative">
                <div className="absolute inset-0 bg-gradient-to-r from-lavender to-teal blur-md opacity-50 rounded-full"></div>
                <div className="relative bg-white rounded-full p-4 shadow-lg">
                  <div className="text-lavender font-semibold">Luv Legend 💫</div>
                </div>
              </div>
            </div>
            
            <Button 
              className="bg-gradient-to-r from-lavender to-teal hover:from-lavender-dark hover:to-teal-dark text-white font-medium mb-4"
              onClick={() => setShowLoyaltyInfo(!showLoyaltyInfo)}
            >
              <Gift className="mr-2 h-4 w-4" /> Join the FlexUrluv Club
            </Button>
            
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="icon" 
                className="rounded-full hover:bg-lavender/10 hover:text-lavender border-gray-200"
              >
                <Instagram className="h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="rounded-full hover:bg-lavender/10 hover:text-lavender border-gray-200"
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="rounded-full hover:bg-lavender/10 hover:text-lavender border-gray-200"
                onClick={handleCopyLink}
              >
                <Copy className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Flex Club Loyalty Program Details */}
        {showLoyaltyInfo && (
          <div className="mt-8 max-w-5xl mx-auto bg-white rounded-xl p-6 border border-gray-100 shadow-md">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-lavender flex items-center justify-center gap-2">
                <Star className="h-5 w-5" /> Flex Club Membership Tiers
              </h3>
              <p className="text-gray-600 mt-2">Earn points through purchases, referrals, and sharing content</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {loyaltyTiers.map((tier, index) => (
                <div 
                  key={tier.name} 
                  className={`p-4 rounded-lg border ${index === loyaltyTiers.length - 1 ? 'bg-gradient-to-r from-lavender/10 to-teal/10 border-teal' : 'bg-white border-gray-200'}`}
                >
                  <h4 className="font-bold text-center mb-2">{tier.name}</h4>
                  <div className="flex justify-center mb-3">
                    <div className="bg-lavender/10 rounded-full px-3 py-1 text-sm font-medium text-lavender">
                      {tier.credits} credits/month
                    </div>
                  </div>
                  <ul className="text-sm space-y-2">
                    {tier.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <div className="mr-2 mt-0.5 text-teal">✓</div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <Button 
                className="bg-gradient-to-r from-lavender to-teal hover:from-lavender-dark hover:to-teal-dark text-white"
              >
                Start Earning Points
              </Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default ReferralSection;
