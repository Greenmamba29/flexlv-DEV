
import React from 'react';
import { Link } from 'react-router-dom';
import HeroSection from '@/components/HeroSection';
import HowItWorks from '@/components/HowItWorks';
import ProductFeatures from '@/components/ProductFeatures';
import Testimonials from '@/components/Testimonials';
import CTASection from '@/components/CTASection';
import ReferralSection from '@/components/ReferralSection';
import { Button } from '@/components/ui/button';
import { Instagram, MessageSquare } from 'lucide-react';

const Index = () => {
  React.useEffect(() => {
    // Set meta tags for SEO
    document.title = "FlexUrluv — Give a Story. Own a Domain.";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "FlexUrluv is the ultimate AI gifting platform. Turn memories into magical stories and give someone a personalized domain they'll never forget.");
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-white/80 border-b border-gray-100">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="font-bold text-2xl bg-clip-text text-transparent bg-gradient-to-r from-lavender to-teal">
              FlexUrluv
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <a href="#how-it-works" className="text-gray-600 hover:text-lavender font-medium transition-colors">How It Works</a>
            <a href="#features" className="text-gray-600 hover:text-lavender font-medium transition-colors">Features</a>
            <Link to="/pricing" className="text-gray-600 hover:text-lavender font-medium transition-colors">Pricing</Link>
            <Link to="/dashboard">
              <Button 
                variant="outline" 
                className="border-lavender text-lavender hover:bg-lavender hover:text-white"
              >
                Dashboard
              </Button>
            </Link>
          </div>
          
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        <HeroSection />
        <HowItWorks />
        <ProductFeatures />
        <Testimonials />
        <CTASection />
        <ReferralSection />
      </main>

      {/* Footer */}
      <footer className="bg-midnight text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-lavender-light to-teal-light">
                FlexUrluv
              </div>
              <p className="text-gray-400">Give a story. Own a domain.</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Product</h3>
              <ul className="space-y-2">
                <li><a href="#how-it-works" className="text-gray-400 hover:text-white transition-colors">How It Works</a></li>
                <li><a href="#features" className="text-gray-400 hover:text-white transition-colors">Features</a></li>
                <li><Link to="/pricing" className="text-gray-400 hover:text-white transition-colors">Pricing</Link></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Examples</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} FlexUrluv. All rights reserved.
            </div>
            
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <MessageSquare className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
