
import React from 'react';
import { Button } from "@/components/ui/button";
import { Book } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-lavender/10 to-teal/10 py-16 md:py-24">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, index) => (
          <div 
            key={index}
            className="sparkle animate-sparkle" 
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`
            }}
          />
        ))}
        <div className="absolute -bottom-48 -right-48 w-96 h-96 bg-lavender/20 rounded-full blur-3xl" />
        <div className="absolute -top-48 -left-48 w-96 h-96 bg-teal/20 rounded-full blur-3xl" />
      </div>
      
      <div className="container px-4 mx-auto relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-16">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-lavender-dark to-teal">
              Turn a Memory Into a Magical Gift
            </h1>
            <p className="text-lg md:text-xl mb-8 text-gray-700 max-w-lg mx-auto lg:mx-0">
              Give a one-of-a-kind storybook and their very own domain — written by AI, inspired by love.
            </p>
            <Button size="lg" className="btn-glow bg-gradient-to-r from-lavender to-teal border-0 text-white hover:from-lavender-dark hover:to-teal-dark text-lg px-8 py-6 shadow-lg">
              <Book className="mr-2 h-5 w-5" /> Create a Story Gift
            </Button>
          </div>
          
          <div className="flex-1 relative">
            <div className="relative w-full max-w-md mx-auto">
              {/* Book Mockup */}
              <div className="relative animate-float shadow-2xl rounded-lg bg-white p-2">
                <div className="bg-gradient-to-br from-lavender-light to-teal-light rounded-md overflow-hidden aspect-[3/4] animate-pulse-glow">
                  <img 
                    src="https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                    alt="Storybook Cover" 
                    className="w-full h-full object-cover opacity-70 mix-blend-overlay"
                  />
                  <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-xl text-center p-4">
                    Josie's Adventures:<br/>The Magic of Being You
                  </div>
                </div>
              </div>
              
              {/* URL Preview */}
              <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 bg-white p-4 rounded-full shadow-xl flex items-center justify-center">
                <div className="text-midnight font-semibold text-sm">
                  JosieTheExplorer.com
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-yellow-100 rounded-full animate-spin-slow opacity-70"></div>
              <div className="absolute -bottom-2 -left-2 w-8 h-8 bg-pink-100 rounded-full animate-spin-slow opacity-70" style={{ animationDelay: "2s" }}></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
