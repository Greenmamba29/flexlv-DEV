import React from 'react';
import { Button } from '../components/ui/button';

const SubscriptionDetails = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Subscription Plans</h1>
      <p className="mb-6 text-gray-700">
        FlexURLuv subscriptions give you more magic, more customization, and more stories to share.
        Choose the plan that fits your vibe and start building beautiful memories that last.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded shadow p-6">
          <h2 className="text-xl font-semibold mb-2">Pro Flex</h2>
          <p className="text-sm text-gray-600 mb-4">$19.99/month</p>
          <ul className="mb-4 list-disc pl-5 text-sm text-gray-700">
            <li>4 AI-generated storybooks/month</li>
            <li>1 custom domain/month</li>
            <li>Priority access to new features</li>
            <li>Save and manage past stories</li>
          </ul>
          <Button className="w-full">Upgrade to Pro</Button>
        </div>

        <div className="bg-white rounded shadow p-6 border-2 border-blue-500">
          <h2 className="text-xl font-semibold mb-2">Premium Flex++</h2>
          <p className="text-sm text-gray-600 mb-4">$39.99/month</p>
          <ul className="mb-4 list-disc pl-5 text-sm text-gray-700">
            <li>Unlimited storybooks</li>
            <li>2 custom domains/month</li>
            <li>AI voice narration</li>
            <li>Branded shareable pages</li>
            <li>VIP early access to seasonal drops</li>
          </ul>
          <Button className="w-full bg-blue-600 text-white">Join Premium++</Button>
        </div>
      </div>

      <div className="mt-10 text-center">
        <p className="text-sm text-gray-500">Cancel anytime. No questions asked.</p>
      </div>
    </div>
  );
};

export default SubscriptionDetails;