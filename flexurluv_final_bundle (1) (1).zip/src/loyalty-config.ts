export const FlexClub = {
  name: "Flex Club",
  creditsPerMonth: 5,
  perks: [
    "Early access to story styles",
    "Free domain after 3 months",
    "Priority support",
    "Exclusive templates"
  ],
  joinRequirement: "Subscription Tier Pro or higher"
};