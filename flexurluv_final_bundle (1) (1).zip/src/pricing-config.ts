export const pricingPlans = [
  {
    name: "Basic Flex",
    price: "$5.99",
    books: "1 storybook included",
    domain: "Domain not included",
    ebookCost: 2.99,
    domainCost: 0,
    features: [
      "AI-generated eBook",
      "QR Code to landing page"
    ],
    upsellAvailable: true,
    upsell: "Upgrade to add domain access and more books"
  },
  {
    name: "Standard Flex",
    price: "$9.99",
    books: "2 storybooks included",
    domain: "Domain not included",
    ebookCost: 2.99,
    domainCost: 0,
    features: [
      "AI-generated eBooks",
      "QR Code to landing page",
      "Option to add domain manually"
    ],
    upsellAvailable: true,
    upsell: "Upgrade for domain access and narration"
  },
  {
    name: "Pro Flex",
    price: "$19.99",
    books: "4 storybooks included",
    domain: "1 domain/month",
    ebookCost: 2.99,
    domainCost: 9.99,
    features: [
      "AI-generated eBooks",
      "QR Code to landing page",
      "One domain/month included"
    ],
    upsellAvailable: true,
    upsell: "Add another domain or unlock more stories"
  },
  {
    name: "Premium Flex++",
    price: "$39.99",
    books: "Unlimited storybooks",
    domain: "2 domains/month",
    ebookCost: 2.99,
    domainCost: 9.99,
    features: [
      "Unlimited eBooks",
      "QR Code to landing page",
      "Two domains/month",
      "Voice narration",
      "Priority support"
    ],
    upsellAvailable: false,
    upsell: ""
  }
];