import React from 'react';
import { FlexClub } from '../loyalty-config';

const FlexClubPage = () => {
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">{FlexClub.name}</h1>
      <p className="mb-4 text-gray-600">
        As a member of the Flex Club, you unlock exclusive perks and premium access each month.
      </p>

      <ul className="list-disc pl-6 text-gray-700 mb-6">
        {FlexClub.perks.map((perk, index) => (
          <li key={index}>{perk}</li>
        ))}
      </ul>

      <p className="text-sm text-gray-500">Available to all users on {FlexClub.joinRequirement}.</p>
    </div>
  );
};

export default FlexClubPage;