import React from 'react';
import { referralSystem } from '../rewards-config';

const ReferralRewardsPage = () => {
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Referral Rewards</h1>
      <p className="mb-4 text-gray-600">
        Invite your friends and unlock amazing rewards as your community grows.
      </p>

      <ul className="list-disc pl-6 text-gray-700">
        {referralSystem.levels.map((level, index) => (
          <li key={index}>
            <strong>Level {level.level}:</strong> {level.reward} (after {level.requiredReferrals} referrals)
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ReferralRewardsPage;