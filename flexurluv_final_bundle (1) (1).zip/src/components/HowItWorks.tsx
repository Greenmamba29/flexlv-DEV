
import React from 'react';
import { Book, Camera, Globe } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      icon: <Camera className="w-10 h-10 text-lavender" />,
      title: "Upload 1–3 photos and tell us what they love",
      description: "Share a few pictures and details about your special someone's interests and personality."
    },
    {
      icon: <Book className="w-10 h-10 text-teal" />,
      title: "Our AI writes a custom storybook, just for them",
      description: "Our AI creates a unique, personalized storybook that captures their essence and adventures."
    },
    {
      icon: <Globe className="w-10 h-10 text-lavender-dark" />,
      title: "We generate a unique domain name and landing page",
      description: "They'll get their very own corner of the internet, complete with their story and photos."
    }
  ];

  return (
    <section className="py-20 bg-white" id="how-it-works">
      <div className="container px-4 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-lavender to-teal mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div 
              key={index} 
              className="card-hover relative border border-gray-100 rounded-2xl p-6 bg-white shadow-sm flex flex-col items-center text-center"
            >
              <div className="bg-gradient-to-br from-lavender-light/40 to-teal-light/40 rounded-full p-4 mb-6">
                {step.icon}
              </div>
              
              <h3 className="text-xl font-bold mb-3">{step.title}</h3>
              <p className="text-gray-600 mb-4">{step.description}</p>
              
              {index === 2 && (
                <div className="mt-4 bg-gradient-to-r from-lavender to-teal p-[1px] rounded-full">
                  <div className="bg-white rounded-full px-4 py-1 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-400"></div>
                    <span className="text-sm font-medium glow-link">yourdomain.com</span>
                  </div>
                </div>
              )}
              
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-8 h-8 bg-gray-50 rounded-full flex items-center justify-center border border-gray-100 text-gray-500 font-semibold">
                {index + 1}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
