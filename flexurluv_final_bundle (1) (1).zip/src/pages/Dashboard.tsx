
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Star, Gift, CreditCard, Book, Globe } from "lucide-react";

const Dashboard = () => {
  // Mock user data - will be replaced with actual user data from Supabase
  const userData = {
    name: "Alex Smith",
    subscription: "Premium",
    nextBilling: "June 10, 2025",
    credits: 3,
    loyaltyTier: "Silver",
    loyaltyPoints: 120,
    domains: ["alexstory.com"],
    stories: [
      { id: 1, title: "Alex's Adventure", created: "May 1, 2025", domain: "alexstory.com" },
      { id: 2, title: "Birthday Surprise", created: "April 15, 2025", domain: null }
    ]
  };

  React.useEffect(() => {
    document.title = "Dashboard - FlexUrluv";
  }, []);

  const handleManageSubscription = () => {
    // Will connect to Stripe Customer Portal
    console.log("Manage subscription clicked");
  };

  const handleBuyCredits = () => {
    // Will open a modal to purchase additional credits
    console.log("Buy credits clicked");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="container px-4 py-12 mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Welcome, {userData.name}</h1>
            <p className="text-gray-600">Manage your stories, domains, and subscription</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={handleManageSubscription} className="bg-lavender hover:bg-lavender-dark">
              <CreditCard className="mr-2 h-4 w-4" /> Manage Subscription
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Subscription Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Your Subscription</CardTitle>
              <CardDescription>Current plan details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Plan:</span>
                <Badge variant="secondary" className="bg-lavender/10 text-lavender">
                  {userData.subscription}
                </Badge>
              </div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Next billing:</span>
                <span>{userData.nextBilling}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Status:</span>
                <Badge variant="outline" className="border-green-500 text-green-600">
                  Active
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Credits Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Story Credits</CardTitle>
              <CardDescription>Available for new stories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center items-center h-20">
                <div className="text-4xl font-bold text-lavender">{userData.credits}</div>
                <div className="text-lg ml-2 text-gray-500">credits</div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={handleBuyCredits}>
                <Book className="mr-2 h-4 w-4" /> Buy Additional Credits
              </Button>
            </CardFooter>
          </Card>

          {/* Loyalty Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center">
                <Star className="h-5 w-5 text-lavender mr-2" /> Flex Club
              </CardTitle>
              <CardDescription>Your loyalty rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Tier:</span>
                <Badge className="bg-gradient-to-r from-lavender to-teal text-white">
                  {userData.loyaltyTier}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Points:</span>
                <span>{userData.loyaltyPoints}</span>
              </div>
              <div className="mt-3 bg-gray-100 h-2 rounded-full">
                <div 
                  className="bg-gradient-to-r from-lavender to-teal h-2 rounded-full" 
                  style={{ width: "60%" }}
                ></div>
              </div>
              <div className="text-xs text-gray-500 text-right mt-1">
                80 points to Gold tier
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <Gift className="mr-2 h-4 w-4" /> Redeem Rewards
              </Button>
            </CardFooter>
          </Card>
        </div>

        <Tabs defaultValue="stories" className="w-full">
          <TabsList className="grid grid-cols-2 w-[400px] mb-8">
            <TabsTrigger value="stories" className="data-[state=active]:bg-lavender data-[state=active]:text-white">
              My Stories
            </TabsTrigger>
            <TabsTrigger value="domains" className="data-[state=active]:bg-lavender data-[state=active]:text-white">
              My Domains
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stories" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Your Stories</CardTitle>
                <CardDescription>Manage your created stories</CardDescription>
              </CardHeader>
              <CardContent>
                {userData.stories.length > 0 ? (
                  <div className="divide-y">
                    {userData.stories.map(story => (
                      <div key={story.id} className="py-4 flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">{story.title}</h3>
                          <p className="text-sm text-gray-500">Created: {story.created}</p>
                        </div>
                        <div className="flex items-center">
                          {story.domain && (
                            <Badge className="mr-2 bg-teal/10 text-teal border-teal">
                              {story.domain}
                            </Badge>
                          )}
                          <Button size="sm" variant="outline">View</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    You haven't created any stories yet
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-gradient-to-r from-lavender to-teal">
                  Create New Story
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="domains" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Your Domains</CardTitle>
                <CardDescription>Manage your registered domains</CardDescription>
              </CardHeader>
              <CardContent>
                {userData.domains.length > 0 ? (
                  <div className="divide-y">
                    {userData.domains.map((domain, index) => (
                      <div key={index} className="py-4 flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">{domain}</h3>
                          <p className="text-sm text-gray-500">Expires: May 1, 2026</p>
                        </div>
                        <div>
                          <Button size="sm" variant="outline">Manage</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    You don't have any domains yet
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button className="w-full">
                  <Globe className="mr-2 h-4 w-4" /> Register New Domain
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;
