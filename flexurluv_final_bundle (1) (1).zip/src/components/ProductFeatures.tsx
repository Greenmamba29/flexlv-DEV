
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const ProductFeatures = () => {
  const [activeTab, setActiveTab] = useState("digital");

  return (
    <section className="py-20 bg-gradient-to-b from-white to-lavender/5" id="features">
      <div className="container px-4 mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What They Get</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A truly unique gift that combines storytelling with digital ownership
          </p>
        </div>
        
        <Tabs defaultValue="digital" className="w-full max-w-4xl mx-auto">
          <TabsList className="grid grid-cols-2 w-[300px] mx-auto mb-8">
            <TabsTrigger value="digital" className="data-[state=active]:bg-lavender data-[state=active]:text-white">
              Digital
            </TabsTrigger>
            <TabsTrigger value="print" className="data-[state=active]:bg-lavender data-[state=active]:text-white">
              Print
            </TabsTrigger>
          </TabsList>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <TabsContent value="digital" className="mt-0">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-1">
                  <div className="rounded-xl overflow-hidden shadow-lg animate-float">
                    <img 
                      src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2940&q=80" 
                      alt="Digital Storybook" 
                      className="w-full h-auto"
                    />
                  </div>
                </div>
                
                <div className="flex-1 space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-lavender/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-lavender flex items-center justify-center text-white text-xs">1</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">A digital AI-generated storybook</h3>
                      <p className="text-gray-600">Beautifully illustrated, personalized story accessible on any device</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-teal/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-teal flex items-center justify-center text-white text-xs">2</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">A one-of-a-kind .com domain</h3>
                      <p className="text-gray-600">Their very own piece of the internet with their name or nickname</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-lavender-dark/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-lavender-dark flex items-center justify-center text-white text-xs">3</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">A custom landing page with QR code</h3>
                      <p className="text-gray-600">Easy to share and access their special story anywhere</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="print" className="mt-0">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-1">
                  <div className="rounded-xl overflow-hidden shadow-lg animate-float">
                    <img 
                      src="https://images.unsplash.com/photo-1516383607781-2d206d16ed5c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2940&q=80" 
                      alt="Printed Storybook" 
                      className="w-full h-auto"
                    />
                  </div>
                </div>
                
                <div className="flex-1 space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-lavender/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-lavender flex items-center justify-center text-white text-xs">1</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">A printed hardcover storybook</h3>
                      <p className="text-gray-600">Premium quality, full-color illustrations with durable binding</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-teal/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-teal flex items-center justify-center text-white text-xs">2</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">A one-of-a-kind .com domain</h3>
                      <p className="text-gray-600">Their very own piece of the internet with their name or nickname</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="bg-lavender-dark/10 rounded-lg p-3">
                      <div className="w-6 h-6 rounded-full bg-lavender-dark flex items-center justify-center text-white text-xs">3</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Gift box with QR code card</h3>
                      <p className="text-gray-600">Elegant packaging with instructions to access their domain</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </section>
  );
};

export default ProductFeatures;
