
import React, { useState } from 'react';
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ArrowRight, Upload, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  recipientName: z.string().min(1, { message: "Name is required" }),
  recipientAge: z.string().optional(),
  relationship: z.string().min(1, { message: "Relationship is required" }),
  interests: z.string().min(10, { message: "Please provide more details about their interests" }),
  // We'll handle photos separately since they're file inputs
});

const CreateStory = () => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [photos, setPhotos] = useState<File[]>([]);
  const [photoPreviewUrls, setPhotoPreviewUrls] = useState<string[]>([]);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      recipientName: "",
      recipientAge: "",
      relationship: "",
      interests: ""
    },
  });

  React.useEffect(() => {
    document.title = "Create Story - FlexUrluv";
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files);
      
      // Only allow up to 3 images total
      const newPhotos = [...photos, ...filesArray].slice(0, 3);
      setPhotos(newPhotos);
      
      // Generate preview URLs
      const newPreviewUrls = newPhotos.map(file => URL.createObjectURL(file));
      setPhotoPreviewUrls(newPreviewUrls);
    }
  };

  const removePhoto = (index: number) => {
    const newPhotos = [...photos];
    const newPreviewUrls = [...photoPreviewUrls];
    
    newPhotos.splice(index, 1);
    newPreviewUrls.splice(index, 1);
    
    setPhotos(newPhotos);
    setPhotoPreviewUrls(newPreviewUrls);
  };

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    } else {
      // Submit the form data and photos
      toast({
        title: "Story Creation Started",
        description: "Your story is being created! We'll notify you when it's ready.",
      });
      console.log('Form data:', data);
      console.log('Photos:', photos);
      // Here we would handle the actual submission to backend
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-lavender/5 to-teal/5">
      <main className="container px-4 py-12 mx-auto">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Create Your Story Gift</h1>
            <p className="text-gray-600">Tell us about your special someone and we'll create a unique story just for them</p>
          </div>

          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>
                  {step === 1 && "Recipient Details"}
                  {step === 2 && "Upload Photos"}
                  {step === 3 && "Review & Submit"}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {[1, 2, 3].map((s) => (
                    <div 
                      key={s} 
                      className={`w-2.5 h-2.5 rounded-full ${
                        s === step ? 'bg-lavender' : s < step ? 'bg-gray-400' : 'bg-gray-200'
                      }`}
                    ></div>
                  ))}
                </div>
              </div>
              <CardDescription>
                {step === 1 && "Tell us who this story is for"}
                {step === 2 && "Upload up to 3 photos to personalize the story"}
                {step === 3 && "Review your information before creating the story"}
              </CardDescription>
            </CardHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <CardContent className="space-y-4">
                  {step === 1 && (
                    <>
                      <FormField
                        control={form.control}
                        name="recipientName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Recipient's Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Alex" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="recipientAge"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Age (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 30" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="relationship"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Relationship</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Friend, Partner, Child" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="interests"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Their Interests & Dreams</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="What do they love? What are their dreams? The more details, the more personalized their story will be."
                                className="min-h-[120px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}
                  
                  {step === 2 && (
                    <div className="space-y-6">
                      <div className="bg-gray-50 p-4 rounded-lg border border-dashed border-gray-300 text-center">
                        <Input
                          type="file"
                          accept="image/*"
                          multiple
                          id="photo-upload"
                          className="hidden"
                          onChange={handleFileChange}
                          disabled={photos.length >= 3}
                        />
                        <label 
                          htmlFor="photo-upload"
                          className={`flex flex-col items-center justify-center cursor-pointer py-6 ${
                            photos.length >= 3 ? 'opacity-50' : ''
                          }`}
                        >
                          <Upload className="h-10 w-10 text-lavender mb-2" />
                          <p className="font-medium">
                            {photos.length === 0 
                              ? 'Upload photos' 
                              : photos.length >= 3 
                                ? 'Maximum photos reached' 
                                : 'Add more photos'}
                          </p>
                          <p className="text-sm text-gray-500 mt-1">
                            Upload up to 3 photos to personalize the story
                          </p>
                        </label>
                      </div>
                      
                      {photoPreviewUrls.length > 0 && (
                        <div>
                          <h4 className="font-medium mb-3">Uploaded Photos:</h4>
                          <div className="grid grid-cols-3 gap-4">
                            {photoPreviewUrls.map((url, index) => (
                              <div key={index} className="relative">
                                <img 
                                  src={url} 
                                  alt={`Upload ${index + 1}`}
                                  className="w-full h-40 object-cover rounded-md"
                                />
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  className="absolute top-2 right-2 h-6 w-6 p-0"
                                  onClick={() => removePhoto(index)}
                                >
                                  ✕
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {step === 3 && (
                    <div className="space-y-4">
                      <div className="bg-lavender/5 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">Recipient Details</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-500">Name:</p>
                            <p>{form.getValues("recipientName")}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Age:</p>
                            <p>{form.getValues("recipientAge") || "Not specified"}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Relationship:</p>
                            <p>{form.getValues("relationship")}</p>
                          </div>
                        </div>
                        <div className="mt-2">
                          <p className="text-sm text-gray-500">Interests & Dreams:</p>
                          <p>{form.getValues("interests")}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2">Photos</h4>
                        {photoPreviewUrls.length > 0 ? (
                          <div className="grid grid-cols-3 gap-4">
                            {photoPreviewUrls.map((url, index) => (
                              <img 
                                key={index}
                                src={url} 
                                alt={`Upload ${index + 1}`}
                                className="w-full h-32 object-cover rounded-md"
                              />
                            ))}
                          </div>
                        ) : (
                          <p className="text-gray-500">No photos uploaded</p>
                        )}
                      </div>
                      
                      <div className="bg-teal/5 p-4 rounded-lg">
                        <h4 className="font-medium mb-2 flex items-center">
                          <Star className="h-4 w-4 text-teal mr-2" /> Domain Options
                        </h4>
                        <p className="text-sm mb-2">
                          After your story is created, you'll have the option to purchase a custom domain name for your recipient.
                        </p>
                        <div className="bg-white p-2 rounded border border-gray-200 text-center">
                          <span className="font-medium">{form.getValues("recipientName").toLowerCase()}story.com</span>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
                
                <CardFooter className="flex justify-between">
                  {step > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(step - 1)}
                    >
                      Back
                    </Button>
                  )}
                  <Button 
                    type="submit" 
                    className={`ml-auto ${step === 3 ? 'bg-gradient-to-r from-lavender to-teal' : ''}`}
                  >
                    {step === 3 ? 'Create Story' : 'Continue'} 
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default CreateStory;
