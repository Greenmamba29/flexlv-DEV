
import React from 'react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Emma K.",
      handle: "@emma_loves_books",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
      text: "💖 My sister cried when she saw her story. Thanks FlexUrluv!! The domain was literally perfect for her.",
      variant: "from-pink-100 to-lavender-light"
    },
    {
      name: "Tyler J.",
      handle: "@tyler_tech",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
      text: "✨ Just gave my girlfriend the most unique anniversary gift ever. She was shook when she saw her name as a website. 10/10 vibes.",
      variant: "from-teal-light to-blue-100"
    },
    {
      name: "Zoe P.",
      handle: "@zoe_creates",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80",
      text: "🔥 No cap, this is the most fire gift I've ever given. My bestie was literally crying. The AI story was so spot on!",
      variant: "from-orange-100 to-yellow-100"
    }
  ];
  
  return (
    <section className="py-20 bg-gradient-to-b from-lavender/5 to-white" id="testimonials">
      <div className="container px-4 mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What People Are Saying</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-lavender to-teal mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="relative overflow-hidden rounded-xl shadow-lg p-6 card-hover"
            >
              {/* Gradient Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${testimonial.variant} opacity-20 z-0`}></div>
              
              {/* Content */}
              <div className="relative z-10">
                <div className="flex items-center mb-4">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name} 
                    className="w-12 h-12 rounded-full object-cover border-2 border-white"
                  />
                  <div className="ml-3">
                    <div className="font-bold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.handle}</div>
                  </div>
                </div>
                <p className="text-gray-700 mb-2">{testimonial.text}</p>
                <div className="text-xs text-gray-400 flex items-center mt-4">
                  <span>2 days ago</span>
                  <span className="mx-1">•</span>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                    </svg>
                    <span className="ml-1">42</span>
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute top-2 right-2 opacity-20 text-2xl animate-pulse-glow">✨</div>
              <div className="absolute bottom-2 left-2 opacity-20 text-2xl animate-pulse-glow" style={{ animationDelay: "1s" }}>💫</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
