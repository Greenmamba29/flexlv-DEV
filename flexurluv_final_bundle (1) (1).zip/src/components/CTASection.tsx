
import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const CTASection = () => {
  return (
    <section className="py-20 relative overflow-hidden" id="cta">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-lavender/90 to-teal/90 opacity-90"></div>
      
      {/* Confetti Elements */}
      {Array.from({ length: 50 }).map((_, index) => (
        <div 
          key={index}
          className="absolute w-2 h-2 rounded-full bg-white opacity-80"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: '100%',
            animationDuration: `${3 + Math.random() * 5}s`,
            animationDelay: `${Math.random() * 5}s`,
          }}
        ></div>
      ))}
      
      <div className="container px-4 mx-auto relative z-10">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 md:p-12 max-w-4xl mx-auto shadow-xl">
          <div className="text-center text-white mb-8">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Who will you surprise with their own little piece of the web?
            </h2>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Create a gift they'll never forget and give them something truly unique - their own story and domain.
            </p>
          </div>
          
          <div className="flex justify-center">
            <Button 
              size="lg"
              className="bg-white text-lavender hover:bg-lavender-light hover:text-lavender-dark text-lg px-8 py-6 font-semibold shadow-xl btn-glow group"
            >
              Make Their Story Now
              <ArrowRight className="ml-2 h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
          
          <div className="mt-8 text-center">
            <p className="text-white text-opacity-80 text-sm">
              Need more info? <a href="#how-it-works" className="underline hover:text-opacity-100">Learn how it works</a> or <a href="#features" className="underline hover:text-opacity-100">see what's included</a>.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
