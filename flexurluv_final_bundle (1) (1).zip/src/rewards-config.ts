export const referralSystem = {
  levels: [
    { level: 1, reward: "1 free storybook", requiredReferrals: 3 },
    { level: 2, reward: "1 free domain", requiredReferrals: 5 },
    { level: 3, reward: "Flex Club unlock", requiredReferrals: 10 }
  ]
};